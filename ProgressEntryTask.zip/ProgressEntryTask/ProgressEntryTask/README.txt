Instructions on how to execute code:
1. Open ProgressEntryTask.sln file using Visual Studio Community 2019.
2. Start program by pressing Start button in the second of the top.
3. Window forms starts, and you need to choose, which task you want to do. MainTask/BonusTask1/BonusTask2.
4. If you press for example MainTask, MessageBox shows thats is completed and csv file is going be generated in the ''Tasks'' folder.
5. If you press BonusTask1, first you need to fill textboxes if textbox is date you need to fill date format: XXXX-XX-XX, if textbox is asking to fill yearly rate, you need to put integer.
6. Same as BonusTask1, BonusTask2 asking first to fill textboxes, if you fill textboxes, then you can press Button to generate csv file, in the ''Tasks'' folder.
