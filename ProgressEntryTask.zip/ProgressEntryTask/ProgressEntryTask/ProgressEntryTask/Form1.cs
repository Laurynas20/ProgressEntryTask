﻿using System;
using System.IO;
using System.Windows.Forms;

namespace ProgressEntryTask
{
    public partial class Form1 : Form
    {
        decimal amount = 10;
        decimal rate = 7;
        string beginDate = "2019-04-15";
        int duration = 24;
        int paymentDay = 23;
        string reinvestOption = "yes";

        int line = 0;
        decimal total_reward = 0;
        int days = 0;
        decimal reward = 0;


        string path = @"..\..\..\Tasks\";


        public Form1()
        {
            InitializeComponent();
        }

        void Reset()
        {
            line = 0;
            total_reward = 0;
            days = 0;
            reward = 0;
            amount = 10;
        }

        public void Algorithm(decimal investmentAmount, decimal rate, StreamWriter sw, DateTime date)
        {
            line++;

            decimal actualRate = (rate / 100) / 365;

            reward = investmentAmount * days * actualRate;

            total_reward += reward;

            sw.WriteLine("{0} , {1} , {2} , {3} , {4} , {5}%", line.ToString(), date.ToString("d"), string.Format("{0:#,0.000000}", investmentAmount), string.Format("{0:#,0.000000}", reward), string.Format("{0:#,0.000000}", total_reward), rate);

            days = 1;

        }

        private void MainTask_Click(object sender, EventArgs e)
        {
            string filename = path + "MainTask.csv";

            StreamWriter sw = new StreamWriter(filename);

            sw.WriteLine("Line #,Reward Date,Investment Amount,Reward Amount,Total Reward Amount To Date,Staking Reward Rate");

            DateTime startDate = DateTime.Parse(beginDate);
            DateTime endDate = startDate.AddMonths(duration);

            for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
            {
                if ( date.Day == paymentDay )
                {
                    Algorithm(amount, rate, sw, date);
                    if ( reinvestOption == "yes" )
                    {
                        amount += reward;
                    }
                }
                else if ( date == endDate )
                {
                    Algorithm(amount, rate, sw, date);
                    Reset();
                }
                else
                {
                    days++;
                }
            }

            MessageBox.Show("Main Task Completed!");

            sw.Flush();
            sw.Close();

        }

        private void BonusTask1_Click(object sender, EventArgs e)
        {
            try
            {
                string newDate;
                newDate = DateText.Text;
                string newRate;
                newRate = RateText.Text;

                decimal rate1 = Convert.ToDecimal(newRate);

                string filename = path + "BonusTask1.csv";

                StreamWriter sw = new StreamWriter(filename);

                sw.WriteLine("Line #,Reward Date,Investment Amount,Reward Amount,Total Reward Amount To Date,Staking Reward Rate");

                DateTime startDate = DateTime.Parse(newDate);
                DateTime endDate = startDate.AddMonths(duration);

                for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
                {
                    if (date.Day == paymentDay)
                    {
                        Algorithm(amount, rate1, sw, date);
                        if (reinvestOption == "yes")
                        {
                            amount += reward;
                        }
                    }
                    else if (date == endDate)
                    {
                        Algorithm(amount, rate1, sw, date);
                        Reset();
                    }
                    else
                    {
                        days++;
                    }
                }

                MessageBox.Show("Bonus Task 1 Completed!");

                sw.Flush();
                sw.Close();

            }catch(Exception ex)
            {
                MessageBox.Show("ERROR: " + ex);
            }
        }

        private void BonusTask2_Click(object sender, EventArgs e)
        {
            try
            {
                decimal amountInput = Convert.ToDecimal(AmountText.Text);
                decimal yearlyInput = Convert.ToDecimal(YearlyText.Text);
                string startDateInput = startDateText.Text;
                int durationInput = Convert.ToInt32(DurationText.Text);
                int paymentDateInput = Convert.ToInt32(PaymentDateText.Text);
                string reinvestInput = ReinvestText.Text;

                string filename = path + "BonusTask2.csv";

                StreamWriter sw = new StreamWriter(filename);

                sw.WriteLine("Line #,Reward Date,Investment Amount,Reward Amount,Total Reward Amount To Date,Staking Reward Rate");

                DateTime startDate = DateTime.Parse(startDateInput);
                DateTime endDate = startDate.AddMonths(duration);

                for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
                {
                    if (date.Day == paymentDateInput)
                    {
                        Algorithm(amountInput, yearlyInput, sw, date);
                        if (reinvestOption == "yes")
                        {
                            amountInput += reward;
                        }
                    }
                    else if (date == endDate)
                    {
                        Algorithm(amountInput, yearlyInput, sw, date);
                        Reset();
                    }
                    else
                    {
                        days++;
                    }
                }

                MessageBox.Show("Bonus Task 2 Completed!");

                sw.Flush();
                sw.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex);
            }
        }

        private void CloseApplication_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
