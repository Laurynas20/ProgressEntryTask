﻿
namespace ProgressEntryTask
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.AmountText = new System.Windows.Forms.TextBox();
            this.RateText = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ReinvestText = new System.Windows.Forms.TextBox();
            this.PaymentDateText = new System.Windows.Forms.TextBox();
            this.startDateText = new System.Windows.Forms.TextBox();
            this.DurationText = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.MainTask = new System.Windows.Forms.Button();
            this.BonusTask1 = new System.Windows.Forms.Button();
            this.BonusTask2 = new System.Windows.Forms.Button();
            this.MainTaskBox = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.DateText = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.YearlyText = new System.Windows.Forms.TextBox();
            this.CloseApplication = new System.Windows.Forms.Button();
            this.MainTaskBox.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(211, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Initial investment amount of ETH";
            // 
            // AmountText
            // 
            this.AmountText.Location = new System.Drawing.Point(234, 45);
            this.AmountText.Name = "AmountText";
            this.AmountText.Size = new System.Drawing.Size(100, 22);
            this.AmountText.TabIndex = 4;
            // 
            // RateText
            // 
            this.RateText.Location = new System.Drawing.Point(216, 98);
            this.RateText.Name = "RateText";
            this.RateText.Size = new System.Drawing.Size(100, 22);
            this.RateText.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Staking start date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Reward payment day";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 294);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 17);
            this.label6.TabIndex = 8;
            this.label6.Text = "Reinvest: Yes/No";
            // 
            // ReinvestText
            // 
            this.ReinvestText.Location = new System.Drawing.Point(234, 291);
            this.ReinvestText.Name = "ReinvestText";
            this.ReinvestText.Size = new System.Drawing.Size(100, 22);
            this.ReinvestText.TabIndex = 11;
            // 
            // PaymentDateText
            // 
            this.PaymentDateText.Location = new System.Drawing.Point(234, 240);
            this.PaymentDateText.Name = "PaymentDateText";
            this.PaymentDateText.Size = new System.Drawing.Size(100, 22);
            this.PaymentDateText.TabIndex = 10;
            // 
            // startDateText
            // 
            this.startDateText.Location = new System.Drawing.Point(234, 142);
            this.startDateText.Name = "startDateText";
            this.startDateText.Size = new System.Drawing.Size(100, 22);
            this.startDateText.TabIndex = 9;
            // 
            // DurationText
            // 
            this.DurationText.Location = new System.Drawing.Point(234, 191);
            this.DurationText.Name = "DurationText";
            this.DurationText.Size = new System.Drawing.Size(100, 22);
            this.DurationText.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 17);
            this.label7.TabIndex = 12;
            this.label7.Text = "Staking duration";
            // 
            // MainTask
            // 
            this.MainTask.Location = new System.Drawing.Point(22, 39);
            this.MainTask.Name = "MainTask";
            this.MainTask.Size = new System.Drawing.Size(128, 30);
            this.MainTask.TabIndex = 14;
            this.MainTask.Text = "Main Task";
            this.MainTask.UseVisualStyleBackColor = true;
            this.MainTask.Click += new System.EventHandler(this.MainTask_Click);
            // 
            // BonusTask1
            // 
            this.BonusTask1.Location = new System.Drawing.Point(188, 140);
            this.BonusTask1.Name = "BonusTask1";
            this.BonusTask1.Size = new System.Drawing.Size(128, 30);
            this.BonusTask1.TabIndex = 15;
            this.BonusTask1.Text = "Bonus Task 1";
            this.BonusTask1.UseVisualStyleBackColor = true;
            this.BonusTask1.Click += new System.EventHandler(this.BonusTask1_Click);
            // 
            // BonusTask2
            // 
            this.BonusTask2.Location = new System.Drawing.Point(206, 335);
            this.BonusTask2.Name = "BonusTask2";
            this.BonusTask2.Size = new System.Drawing.Size(128, 30);
            this.BonusTask2.TabIndex = 16;
            this.BonusTask2.Text = "Bonus Task 2";
            this.BonusTask2.UseVisualStyleBackColor = true;
            this.BonusTask2.Click += new System.EventHandler(this.BonusTask2_Click);
            // 
            // MainTaskBox
            // 
            this.MainTaskBox.Controls.Add(this.MainTask);
            this.MainTaskBox.Location = new System.Drawing.Point(392, 12);
            this.MainTaskBox.Name = "MainTaskBox";
            this.MainTaskBox.Size = new System.Drawing.Size(179, 89);
            this.MainTaskBox.TabIndex = 17;
            this.MainTaskBox.TabStop = false;
            this.MainTaskBox.Text = "Main Task";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.DateText);
            this.groupBox2.Controls.Add(this.BonusTask1);
            this.groupBox2.Controls.Add(this.RateText);
            this.groupBox2.Location = new System.Drawing.Point(392, 118);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(335, 188);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bonus Task 1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 101);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(204, 17);
            this.label9.TabIndex = 19;
            this.label9.Text = "Yearly staking reward rate in %";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 17);
            this.label1.TabIndex = 16;
            this.label1.Text = "Staking start date";
            // 
            // DateText
            // 
            this.DateText.Location = new System.Drawing.Point(216, 51);
            this.DateText.Name = "DateText";
            this.DateText.Size = new System.Drawing.Size(100, 22);
            this.DateText.TabIndex = 17;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.YearlyText);
            this.groupBox3.Controls.Add(this.BonusTask2);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.AmountText);
            this.groupBox3.Controls.Add(this.DurationText);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.ReinvestText);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.PaymentDateText);
            this.groupBox3.Controls.Add(this.startDateText);
            this.groupBox3.Location = new System.Drawing.Point(12, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(365, 387);
            this.groupBox3.TabIndex = 19;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Bonus Task 2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(204, 17);
            this.label8.TabIndex = 17;
            this.label8.Text = "Yearly staking reward rate in %";
            // 
            // YearlyText
            // 
            this.YearlyText.Location = new System.Drawing.Point(234, 94);
            this.YearlyText.Name = "YearlyText";
            this.YearlyText.Size = new System.Drawing.Size(100, 22);
            this.YearlyText.TabIndex = 18;
            // 
            // CloseApplication
            // 
            this.CloseApplication.Location = new System.Drawing.Point(598, 356);
            this.CloseApplication.Name = "CloseApplication";
            this.CloseApplication.Size = new System.Drawing.Size(129, 43);
            this.CloseApplication.TabIndex = 20;
            this.CloseApplication.Text = "Close";
            this.CloseApplication.UseVisualStyleBackColor = true;
            this.CloseApplication.Click += new System.EventHandler(this.CloseApplication_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(745, 417);
            this.Controls.Add(this.CloseApplication);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.MainTaskBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.MainTaskBox.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox AmountText;
        private System.Windows.Forms.TextBox RateText;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ReinvestText;
        private System.Windows.Forms.TextBox PaymentDateText;
        private System.Windows.Forms.TextBox startDateText;
        private System.Windows.Forms.TextBox DurationText;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button MainTask;
        private System.Windows.Forms.Button BonusTask1;
        private System.Windows.Forms.Button BonusTask2;
        private System.Windows.Forms.GroupBox MainTaskBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox DateText;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox YearlyText;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button CloseApplication;
    }
}

